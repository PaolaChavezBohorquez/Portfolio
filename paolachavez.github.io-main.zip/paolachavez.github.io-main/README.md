# paolachavez.github.io
Especialista en Branding y Psicología del Consumidor | Analista de Mercadeo | Gestión Comercial | Creación de Marcas con Impacto. Branding &amp; Consumer Psychology Expert
